﻿namespace SoftUni;

using SoftUni.Data;

public class StartUp
    {
        static void Main(string[] args)
        {

            SoftUniContext dbContext = new SoftUniContext();
            

        }
    }
