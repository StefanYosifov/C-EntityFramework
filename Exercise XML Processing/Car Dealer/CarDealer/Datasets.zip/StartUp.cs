﻿namespace CarDealer
{
    using AutoMapper;
    using CarDealer.Data;
    using CarDealer.DTOs.Import;
    using CarDealer.Models;
    using CarDealer.Utilities;
    using System.Xml.Serialization;

    public class StartUp
    {
        public static void Main()
        {

            using var context = new CarDealerContext();
            string xmlDatasets = "../../../Datasets/";

            string suppliersXml = File.ReadAllText(xmlDatasets + "suppliers.xml");
            Console.WriteLine(ImportSuppliers(context, suppliersXml));


        }
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlHelper helper = new XmlHelper();
            ImportSuplierDto[] suplierDtos = helper.Deserialize<ImportSuplierDto[]>(inputXml, "Suppliers");

            ICollection<Supplier> suppliers = new HashSet<Supplier>();
            IMapper mapper = CreateMapper();
            foreach(var supplierDto in suplierDtos)
            {
                if (string.IsNullOrEmpty(supplierDto.Name))
                {
                    continue;
                }

                var supplier = mapper.Map<Supplier>(supplierDto);
                suppliers.Add(supplier);

            }

            context.AddRange(suppliers);
            context.SaveChanges();
            return $"Successfully imported {suppliers.Count}";
        }

        private static IMapper CreateMapper()
        {
            MapperConfiguration configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });

            IMapper mapper = new Mapper(configuration);

            return mapper;
           
        }
    }
}