﻿namespace ProductShop.DTOs.Import
{
 

    public class ImportCategoriesDto
    {

        public string Name { get; set; } = null!;
    }
}
