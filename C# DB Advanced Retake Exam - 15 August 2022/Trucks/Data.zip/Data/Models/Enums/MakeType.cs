﻿namespace Trucks.Data.Models.Enums
{


    public enum MakeType
    {

        Daf=1, 
        Man=2, 
        Mercedes=3,
        Scania=4, 
        Volvo=5,

    }
}
