﻿namespace Trucks.Data.Models.Enums
{


    public enum CategoryType
    {
        Flatbed=1,
        Jumbo=2,
        Refrigerated=3,
        Semi=4,

    }
}
