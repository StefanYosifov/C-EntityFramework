﻿namespace SoftJail.Data.Models.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Position
    {
        Overseer=1, 
        Guard=2, 
        Watcher=3, 
        Labour=4,
    }
}
